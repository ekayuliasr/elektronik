<!-- footer -->
	<div class="footer">
		<div class="footer-copy">
			<div class="footer-copy1">
				<div class="footer-copy-pos">
					<a href="<?php echo site_url('news'); ?>" class="scroll"><img src="assets/images/arrow.png" alt=" " class="img-responsive" /></a>
				</div>
			</div>
			<div class="container">
				<p>&copy; 2018 Eka Putri Store| Design by Eka Yulia Agustina Sari (173140914111043)</p>
			</div>
		</div>
	</div>
	<!-- //footer --> 
</body>
</html>


