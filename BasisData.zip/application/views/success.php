	<div class="new-products">
		<div class="container">
			<p> Data added successfully! </p>
		</div>
	</div>