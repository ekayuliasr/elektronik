	<div class="new-products">
		<div class="container">
				<h3> About Us </h3>
				<p> Eka Putri Store merupakan sebuah toko elektronik yang menyediakan berbagai tipe barang dimana customer <br>  
				dapat mengetahui barang barang yang tersedia di sini. Namun Eka Putri Store tidak melayani pembelian online. Jika <br> ingin berbelanja di Eka Putri Store, anda dapat mengunjungi toko kami di Jalan Raya Penampan - Sumobito Jombang. <br>
				Toko kami buka dari Setiap hari Sabtu-Kamis pukul 08.00 hingga 17.00. Anda dapat menghubungi (0321)445-445 jika ingin <br>
				megetahui seputar toko kami lebih lanjut<br>
				Terima Kasih.</p>
		</div>
	</div>
	
