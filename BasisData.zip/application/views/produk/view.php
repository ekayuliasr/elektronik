<div class="new-products">
	<div class="container">
		<?php
			echo '<h2>'.$produk_item['namabarang'].'</h2>';
			echo $produk_item['gambar'];
			echo "<br />";
			echo $produk_item['kodebarang'];
			echo "<br />";
			echo $produk_item['spesifikasi'];
			echo "<br />";
			echo $produk_item['harga'];
			echo "<br />";
			echo $produk_item['stok'];
			echo "<br />";
		?>
	</div>
</div>
