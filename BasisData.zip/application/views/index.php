	<div class="new-products">
		<div class="container">
				<h3> Welcome to Eka Putri Store </h3>
				<?php echo $this->session->userdata('username'); ?> success login as ADMIN
		</div>
	</div>
	
